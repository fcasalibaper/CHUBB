import { General } from './general/general';
import { Menu } from './general/menu';